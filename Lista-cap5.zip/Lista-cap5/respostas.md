# Lista de Exercícios – Capítulo 5: Funções

**Disciplina:** Programação Imperativa e Funcional (PIF) — CESAR School
**Aluno:** João Victor Queiroz Medeiros Goularte
**Semestre:** 2026.2

> Respostas das questões teóricas (01 a 06). As questões de código (07 a 28) estão nos arquivos `questaoXX.c`.

---

## Questão 01 — Anatomia de uma Função e o Papel do Protótipo

**a)** No programa:

- **Protótipo:** `float celsius(float);` (antes da `main`). Anuncia ao compilador o nome da função, o tipo de retorno e os tipos dos parâmetros, sem o corpo.
- **Chamada:** `c = celsius(f);` (dentro da `main`). É o momento em que a função é executada: o valor de `f` é passado como argumento e o valor retornado é guardado em `c`.
- **Definição:** `float celsius(float fahr) { return (fahr - 32.0) * 5.0 / 9.0; }` (depois da `main`). É a implementação, o corpo que realiza o cálculo e devolve o resultado.

**b)** O protótipo permite ao compilador **verificar** se as chamadas estão corretas: quantidade de argumentos, tipos dos argumentos (com conversão automática quando possível) e uso correto do valor de retorno. Se ele fosse omitido e a função fosse definida depois da `main`, o compilador chegaria à chamada sem conhecer a função. Em compiladores antigos (C89), ele assumiria uma declaração implícita com retorno `int` e **sem checar os parâmetros**, o que geraria resultados errados (o `float` retornado seria interpretado como `int`). Em compiladores modernos (C99 ou superior), isso gera aviso ou erro de compilação.

**c)** O tipo da função `celsius()` é **`float`**. O tipo da função é o do valor que ela devolve, porque a chamada `celsius(f)` funciona como uma expressão que *vale* o valor retornado e pode ser usada em atribuições e cálculos; o compilador precisa saber de que tipo é esse valor. Os parâmetros apenas descrevem os dados de entrada e não determinam o tipo do resultado produzido.

---

## Questão 02 — O Comando `return` e suas Limitações

**a)** Uma função em C devolve **apenas um valor** por meio de `return`. Na função `calcular()`, o programador pretendia devolver a soma **e** a média, mas `return soma, media;` usa o **operador vírgula**: as duas expressões são avaliadas e só o último valor (`media`) é devolvido. A `soma` é descartada, então o objetivo não é cumprido (e o compilador ainda costuma emitir aviso).

**b)** O `return;` dentro de `imprime_mensagem()` **encerra a função imediatamente**, voltando ao ponto de chamada sem devolver valor. Assim, quando `erro < 0`, a mensagem de erro é impressa e a segunda linha não é executada. Ele **não é obrigatório** no final de uma função `void`: quando a execução chega à chave de fechamento `}`, a função termina sozinha.

**c)** Reescrita:

```c
int media(int a, int b, int c) {
    return (a + b + c) / 3;
}

int soma(int a, int b, int c) {
    return a + b + c;
}
```

Em C precisamos de duas funções porque `return` só carrega **um único valor** por vez. Para devolver dois resultados diferentes, é preciso separar a tarefa em duas funções (ou usar outros recursos, como ponteiros, vistos adiante).

---

## Questão 03 — Funções `void`, Parâmetros e Assinaturas

**a)**

| Protótipo | Parâmetros de entrada | Valor de retorno |
|---|---|---|
| `void exibe_mensagem(char* msg);` | Sim (um `char*`, ou seja, uma string) | Não (`void`) |
| `int obter_codigo(void);` | Não | Sim (`int`) |
| `void limpar_tela(void);` | Não | Não |

**b)** Uma **função com retorno** calcula e devolve um valor ao chamador, que pode usá-lo em expressões. Um **procedimento** (`void`) apenas executa uma ação, sem devolver resultado.

- Função com retorno é a melhor escolha quando se precisa de um **resultado**, por exemplo calcular a média de notas (`float media(...)`).
- Procedimento é a melhor escolha quando o objetivo é um **efeito**, como imprimir um menu ou limpar a tela (`void exibeMenu(void)`).

**c)** **Não é válida.** `limpar_tela()` é do tipo `void`, isto é, não produz valor algum. Atribuir "nada" a `x` é um erro de compilação (o compilador acusa que um valor `void` não é ignorado/atribuível). A forma correta é só `limpar_tela();`.

---

## Questão 04 — Recursão: Caso Base, Passo Recursivo e Pilha de Execução

**a)**

- **Caso base:** `n == 0`, que devolve `1` sem nova chamada.
- **Passo recursivo:** `n * fatorial(n - 1)`, que reduz o problema para um valor menor.

Se o caso base fosse removido, a função chamaria a si mesma indefinidamente (`n` ficaria cada vez mais negativo), sem nunca parar, até estourar a pilha de execução.

**b)** Rastreamento de `fatorial(4)`:

**Empilhamento** (chamadas abertas, aguardando resultado):

```
fatorial(4) = 4 * fatorial(3)
 fatorial(3) = 3 * fatorial(2)
  fatorial(2) = 2 * fatorial(1)
   fatorial(1) = 1 * fatorial(0)
    fatorial(0) -> caso base, devolve 1
```

**Desempilhamento** (valores devolvidos):

```
fatorial(0) devolve 1
fatorial(1) devolve 1 * 1  = 1
fatorial(2) devolve 2 * 1  = 2
fatorial(3) devolve 3 * 2  = 6
fatorial(4) devolve 4 * 6  = 24
```

Resultado final: **24**.

**c)** A cada chamada, o sistema cria na **pilha de execução** um novo *quadro* (stack frame) com os parâmetros, as variáveis locais e o endereço de retorno daquela chamada. Cada chamada fica "suspensa" esperando a seguinte terminar. No desempilhamento, cada quadro é removido à medida que devolve seu valor. Sem caso base, os quadros continuam sendo empilhados sem parar até o limite da memória da pilha ser excedido, causando **estouro de pilha** (*stack overflow*), e o programa é encerrado com falha (por exemplo, *segmentation fault*).

---

## Questão 05 — Diretiva `#define`, Constantes e Macros com Argumentos

**a)** Saída:

```
25
8
```

- `SQR(2+3)` expande para `((2+3)*(2+3))` = 5 × 5 = **25**. Os parênteses em volta do argumento preservam a ordem desejada.
- `DOBRO(2+3)` expande para `2+3*2`. Como `*` tem precedência sobre `+`, resulta em 2 + 6 = **8** (e não 10). Faltaram os parênteses de proteção: `((x)*2)`.

**b)** `#define` é uma diretiva do **pré-processador**, não um comando da linguagem C. Ela vai até o fim da linha e o texto após o nome faz parte da substituição, então um `;` seria copiado junto para todos os lugares onde a macro é usada, podendo causar erros (ex.: `x = PI;;` ou `int v[N;]`). Por convenção usamos **maiúsculas** para distinguir facilmente macros e constantes de variáveis e funções no código.

**c)** `#define PRN (n) printf("%d", n)` está incorreto porque o **espaço** entre `PRN` e `(n)` faz o pré-processador entender uma macro **sem argumentos** chamada `PRN`, cuja substituição é o texto `(n) printf("%d", n)`. A forma correta é sem espaço:

```c
#define PRN(n) printf("%d", n)
```

Diferenças entre macro com argumentos e função: a macro faz **substituição textual** antes da compilação (sem chamada, sem verificação de tipos e sem pilha), enquanto a função é compilada, tem tipos checados e recebe seus argumentos avaliados uma única vez. Por isso, macros podem avaliar o argumento várias vezes (por exemplo, `SQR(i++)` incrementa `i` duas vezes) e exigem parênteses de proteção.

---

## Questão 06 — Diretivas `#include`, `#undef` e Compilação Condicional

**a)**

- `#include <stdio.h>`: com **sinais de menor/maior**, o pré-processador procura o arquivo nos diretórios padrão do sistema/compilador. Usamos para as bibliotecas padrão da linguagem.
- `#include "areas.h"`: com **aspas**, procura primeiro no diretório do próprio projeto (o do arquivo atual) e, se não encontrar, nos diretórios padrão. Usamos para cabeçalhos criados pelo programador.

**b)** `#undef SOMA` **remove a definição** da macro `SOMA`, de modo que, a partir dali, ela deixa de existir (podendo ser redefinida ou o nome ser usado normalmente). A forma `#undef SOMA(x,y)` está incorreta porque `#undef` recebe **somente o identificador** (o nome da macro), sem a lista de parâmetros.

**c)** Se `DEBUG` não foi definido, será impresso **`Modo normal`**. Essa decisão é tomada no **pré-processamento**, antes da compilação: o pré-processador mantém apenas o trecho do `#else` e descarta o outro. As diretivas (`#ifdef`, `#else`, `#endif`, etc.) são instruções para o pré-processador e são **removidas** na etapa de pré-processamento, por isso não existem no executável final, que contém apenas o código do ramo escolhido.

> Observação: no trecho do enunciado, o `printf` aparece solto, fora de uma função; em um programa real, esse bloco precisa ficar dentro de `main()` ou de outra função.
